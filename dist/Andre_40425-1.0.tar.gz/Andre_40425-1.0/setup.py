from setuptools import setup

setup(
    name="Andre_40425",
    version="1.0",
    description="Paquete",
    author="André Abreo",
    author_email="drbuitre@gmail.com",
    
    packages=["entrega2","entrega1"],
)